import java.util.Scanner;

public class CommandLineInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bem-vindo à Calculadora de Derivadas!");
        System.out.println("Digite a função a ser analisada (por exemplo, '2x^3 + 3x^2 - 5x + 7'):");
        String expression = scanner.nextLine();

        Function function = new Function(expression);
        String derivative = function.calculateDerivative();

        System.out.println("A derivada da função é: " + derivative);

        scanner.close();
    }
}
