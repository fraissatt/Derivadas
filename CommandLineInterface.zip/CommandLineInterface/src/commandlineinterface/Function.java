import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Function {
    private String expression;

    public Function(String expression) {
        this.expression = expression;
    }

    public String calculateDerivative() {
        StringBuilder derivative = new StringBuilder();

        // RegEx para encontrar termos na expressão da função
        Pattern termPattern = Pattern.compile("([-+]?\\d*\\.?\\d*)?x(\\^([-+]?\\d*\\.?\\d*))?");
        Matcher matcher = termPattern.matcher(expression);

        boolean isFirstTerm = true;

        while (matcher.find()) {
            double coefficient = 0;
            int exponent = 1;

            // Coeficiente
            String coefficientStr = matcher.group(1);
            if (coefficientStr != null && !coefficientStr.isEmpty()) {
                coefficient = Double.parseDouble(coefficientStr);
            } else {
                coefficient = 1;
            }

            // Expoente
            String exponentStr = matcher.group(3);
            if (exponentStr != null && !exponentStr.isEmpty()) {
                exponent = Integer.parseInt(exponentStr);
            }

            // Calcula a derivada do termo
            double derivativeCoefficient = coefficient * exponent;
            int derivativeExponent = exponent - 1;

            // Constrói o termo da derivada
            if (derivativeCoefficient != 0) {
                if (!isFirstTerm) {
                    derivative.append(" + ");
                }

                // Adiciona o termo do coeficiente da derivada
                derivative.append(derivativeCoefficient);

                // Adiciona o termo do expoente e 'x' se o expoente for maior que 0
                if (derivativeExponent > 0) {
                    derivative.append("x");
                    if (derivativeExponent != 1) {
                        derivative.append("^").append(derivativeExponent);
                    }
                }

                isFirstTerm = false;
            }
        }

        // Se a derivada for vazia, retorna '0'
        if (derivative.length() == 0) {
            derivative.append("0");
        }

        return derivative.toString();
    }
}
